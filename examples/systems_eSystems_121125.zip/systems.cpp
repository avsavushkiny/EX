#include "systems.h"

// Устанавливаем значения системы
Systems _SYS(false, 143, true, true, false, 1);